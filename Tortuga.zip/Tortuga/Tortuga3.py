import turtle
import time

turtle.forward(100)
turtle.right(90)
turtle.forward(100)
turtle.right(90)
turtle.forward(100)
turtle.right(90)
turtle.forward(100)
turtle.left(-45)
turtle.forward(71)
turtle.left(-90)
turtle.forward(71)
turtle.left(-90)
turtle.forward(140)
turtle.left(-135)
turtle.penup()
turtle.forward(100)
turtle.pendown()
turtle.left(-135)
turtle.forward(140)

time.sleep(5)