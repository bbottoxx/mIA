import turtle
import time

#turtle.left(45)
for x in range(10):
    turtle.forward(10)
    turtle.penup()
    turtle.forward(10)
    turtle.pendown()

time.sleep(5)