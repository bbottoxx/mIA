import turtle
import time

for i in range(6):
    turtle.forward(120)
    turtle.right(-60)

time.sleep(5)