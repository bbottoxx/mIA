import turtle
import time

turtle.penup()
turtle.forward(-250)
turtle.pendown()

for i in range(4):
    turtle.forward(50)
    turtle.right(-90)


turtle.penup()
turtle.forward(100)
turtle.pendown()

for i in range(3):
    turtle.forward(80)
    turtle.right(-120)

turtle.penup()
turtle.forward(150)
turtle.pendown()

for i in range(5):
    turtle.forward(120)
    turtle.right(-72)



time.sleep(5)