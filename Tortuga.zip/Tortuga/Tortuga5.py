import turtle
import time

x=20
#turtle.left(45)
for x in range(10):
    turtle.forward(x)
    turtle.penup()
    turtle.forward(x)
    turtle.pendown()
    x=x+10

time.sleep(5)