import turtle
import time

g = 70
for i in range(4):
    turtle.right(g)
    turtle.forward(100)
    turtle.right(90)
    turtle.forward(100)
    turtle.right(90)
    turtle.forward(100)
    turtle.right(90)
    turtle.forward(100)
    

time.sleep(5)